function drawScene(gl, programInfo, buffers, texture, cubeRotation) {
  gl.clearColor(0, 0, 0, 1);
  gl.clearDepth(1.0); 
  gl.enable(gl.DEPTH_TEST);
  gl.depthFunc(gl.LEQUAL);

  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

  const angleOfView = Math.PI / 4;
  const aspectRadio = gl.canvas.clientWidth / gl.canvas.clientHeight;
  const zNear = 0.1;
  const zFar = 100.0;

  const projectionMatrix = mat4.create();

  mat4.perspective(projectionMatrix, angleOfView, aspectRadio, zNear, zFar);

  const modelViewMatrix = mat4.create(); 
  
  mat4.translate(
    modelViewMatrix, // destination matrixW
    modelViewMatrix, // matrix to translate
    [-0.0, 0.0, -6.0]
  );

  mat4.rotate(
    modelViewMatrix, //dest matrix
    modelViewMatrix, //source matrix
    cubeRotation, //amount to rotate in rad
    [0, 0, 1] // rotate z
  );
  mat4.rotate(
    modelViewMatrix, //dest matrix
    modelViewMatrix, //source matrix
    cubeRotation * 0.7, //amount to rotate in rad
    [0, 1, 0] // rotate y
  );

  mat4.rotate(
    modelViewMatrix, //dest matrix
    modelViewMatrix, //source matrix
    cubeRotation * 0.3, //amount to rotate in rad
    [1, 0, 0] // rotate x
  );

  const normalMatrix = mat4.create();
  mat4.invert(normalMatrix, modelViewMatrix);
  mat4.transpose(normalMatrix, normalMatrix);

  
  setPositionAttribute(gl, buffers, programInfo);

  //setColorAttribute(gl, buffers, programInfo);
  
  setTextureAttribute(gl, buffers, programInfo);

  
  setNormalAttribute(gl, buffers, programInfo);

  
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.indices);

  
  gl.useProgram(programInfo.program);

  
  gl.uniformMatrix4fv(
    programInfo.uniformLocations.projectionMatrix,
    false,
    projectionMatrix
  );

  gl.uniformMatrix4fv(
    programInfo.uniformLocations.modelViewMatrix,
    false,
    modelViewMatrix
  );
  {
    const offset = 0;
    const vertexCount = 36;
    const type = gl.UNSIGNED_SHORT;
    gl.drawElements(gl.TRIANGLES, vertexCount, type, offset);
  }
  gl.uniformMatrix4fv(
    programInfo.uniformLocations.normalMatrix,
    false,
    normalMatrix
  );
  
  // Tell WebGL we want to affect texture unit 0
  gl.activeTexture(gl.TEXTURE0);
  // Bind the texture to texture unit 0
  gl.bindTexture(gl.TEXTURE_2D, texture);
  // Tell the shader we bound the texture to texture unit 0
  gl.uniform1i(programInfo.uniformLocations.uSampler, 0);
}
/**END OF DRAW SCENE() FUNCTION */

function setPositionAttribute(gl, buffers, programInfo) {
  const numComponents = 3;  
  const type = gl.FLOAT;
  const normalize = false;
  const stride = 0;  
  const offset = 0;  

  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.position);
  gl.vertexAttribPointer(
    programInfo.attribLocations.vertexPosition,
    numComponents,
    type,
    normalize,
    stride,
    offset
  );
  gl.enableVertexAttribArray(programInfo.attribLocations.vertexPosition);
}

function setColorAttribute(gl, buffers, programInfo) {
  const numComponents = 4; 
  const type = gl.FLOAT;
  const normalize = false;
  const stride = 0;  
  const offset = 0; 

  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.color);
  gl.vertexAttribPointer(
    programInfo.attribLocations.vertexColor,
    numComponents,
    type,
    normalize,
    stride,
    offset
  );
  gl.enableVertexAttribArray(programInfo.attribLocations.vertexColor);
}

// Draw a textured cube
function setTextureAttribute(gl, buffers, programInfo) {
  const num = 2; 
  const type = gl.FLOAT;
  const normalize = false;
  const stride = 0; // number of bytes to get from one set to the next
  const offset = 0; 
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.textureCoord);
  gl.vertexAttribPointer(
    programInfo.attribLocations.textureCoord,
    num,
    type,
    normalize,
    stride,
    offset
  );
  gl.enableVertexAttribArray(programInfo.attribLocations.textureCoord);
}

// Tell WebGL how to pull out the normals from
// the normal buffer into the vertexNormal attribute.
function setNormalAttribute(gl, buffers, programInfo) {
  const numComponents = 3;
  const type = gl.FLOAT;
  const normalize = false;
  const stride = 0;
  const offset = 0;
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.normal);
  gl.vertexAttribPointer(
    programInfo.attribLocations.vertexNormal,
    numComponents,
    type,
    normalize,
    stride,
    offset
  );
  gl.enableVertexAttribArray(programInfo.attribLocations.vertexNormal);
}

export { drawScene };
         